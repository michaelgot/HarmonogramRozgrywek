﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using FirebirdSql.Data.FirebirdClient;
using System.IO;

namespace HarmonogramRozgrywek
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string ścieżkaDatabase;

        private void ButtonGenerujSezon_Click(object sender, EventArgs e)
        {
            new Thread(() =>
            {
                groupBox_3.Enabled = false;
                GenerujTablicęRozgrywkową generujRozgrywki = new GenerujTablicęRozgrywkową();
                string[] tablica = generujRozgrywki.LosowoGenerujKolejnośćPar();

                GenerujDaty generujDaty = new GenerujDaty();
                string dataZimowa, dataLetnia;
                DateTime dataZima, dataLato;
                if (radioButton1.Checked) { dataZimowa = radioButton1.Text; dataZima = Convert.ToDateTime(dataZimowa); generujDaty.DataRundaZimowa = dataZima; }
                else if (radioButton2.Checked) { dataZimowa = radioButton2.Text; dataZima = Convert.ToDateTime(dataZimowa); generujDaty.DataRundaZimowa = dataZima; }
                else if (radioButton3.Checked) { dataZimowa = radioButton3.Text; dataZima = Convert.ToDateTime(dataZimowa); generujDaty.DataRundaZimowa = dataZima; }
                else if (radioButton4.Checked) { dataZimowa = radioButton4.Text; dataZima = Convert.ToDateTime(dataZimowa); generujDaty.DataRundaZimowa = dataZima; }
                if (radioButton5.Checked) { dataLetnia = radioButton5.Text; dataLato = Convert.ToDateTime(dataLetnia); generujDaty.DataRundaLetnia = dataLato; }
                else if (radioButton6.Checked) { dataLetnia = radioButton6.Text; dataLato = Convert.ToDateTime(dataLetnia); generujDaty.DataRundaLetnia = dataLato; }
                else if (radioButton7.Checked) { dataLetnia = radioButton7.Text; dataLato = Convert.ToDateTime(dataLetnia); generujDaty.DataRundaLetnia = dataLato; }
                else if (radioButton8.Checked) { dataLetnia = radioButton8.Text; dataLato = Convert.ToDateTime(dataLetnia); generujDaty.DataRundaLetnia = dataLato; }
                DateTime[] daty = generujDaty.Generuj();
                groupBox_2.Enabled = false;
                
                string Scieżka = "User = SYSDBA;" +
                    "Password = masterkey;" +
                    "Database = " + ścieżkaDatabase + ";";
                FbConnection Połączenie = new FbConnection(Scieżka);
                Połączenie.Open();
                FbCommand Rozkaz = new FbCommand();
                FbDataReader Odczyt;
                string[] tablicaParZespołów = new string[240];
                Rozkaz.Connection = Połączenie;
                string Zapytanie1, Zapytanie2, przechowalnia;
                byte licznikDat = 0;
                for (int i = 0; i < tablica.Length; i++)
                {
                    Zapytanie1 = "select z.nazwa from zespoly z where z.id_zespolu = " + tablica[i].Substring(0, 2);
                    Rozkaz.CommandText = Zapytanie1;
                    Odczyt = Rozkaz.ExecuteReader();
                    Odczyt.Read();
                    przechowalnia = Odczyt.GetString(0);
                    Odczyt.Close();
                    Zapytanie2 = "select z.nazwa from zespoly z where z.id_zespolu = " + tablica[i].Substring(3, 2);
                    Rozkaz.CommandText = Zapytanie2;
                    Odczyt = Rozkaz.ExecuteReader();
                    Odczyt.Read();
                    tablicaParZespołów[i] = przechowalnia + " : " + Odczyt.GetString(0);
                    Odczyt.Close();
                    string wpis = "";
                    if (i > 3 && i % 4 == 0)
                    {
                        wpis = daty[++licznikDat].ToShortDateString() + "   " + tablicaParZespołów[i];
                        listBox_Wyświetl.Items.Add(wpis);
                    }
                    else
                    {
                        wpis = daty[licznikDat].ToShortDateString() + "   " + tablicaParZespołów[i];
                        listBox_Wyświetl.Items.Add(wpis);
                    }
                    Thread.Sleep(10);
                }
                Połączenie.Close();
                groupBox_4.Enabled = true;
            }).Start();
            
        }

        private void button_Otwórz_Click(object sender, EventArgs e)
        {
            OpenFileDialog otwórzPlik = new OpenFileDialog();
            otwórzPlik.Filter = "FDB|*.fdb";
            if (otwórzPlik.ShowDialog() == DialogResult.OK)
            {
                textBox_nazwaPliku.Text = otwórzPlik.SafeFileName;
                ścieżkaDatabase = otwórzPlik.FileName;
                if (otwórzPlik.SafeFileName == "ZESPOLY.FDB")
                {
                    groupBox_2.Enabled = true;
                    groupBox_3.Enabled = true;
                    groupBox_1.Enabled = false;
                }
                else groupBox_3.Enabled = false;
            }

        }

        private void button_Zapisz_Click(object sender, EventArgs e)
        {
            SaveFileDialog zapiszPlik = new SaveFileDialog();
            zapiszPlik.InitialDirectory = @"C:\";
            zapiszPlik.FileName = "*.txt";
            zapiszPlik.DefaultExt = "txt";
            zapiszPlik.Filter = "txt files (*.txt)|*.txt";
            if (zapiszPlik.ShowDialog() == DialogResult.OK)
            {
                Stream plik = zapiszPlik.OpenFile();
                StreamWriter zapisz = new StreamWriter(plik);
                foreach(string i in listBox_Wyświetl.Items)
                {
                    zapisz.WriteLine(i);
                }
                zapisz.Close();
                plik.Close();
            }
        }
    }
}
