﻿namespace HarmonogramRozgrywek
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_GenerujSezon = new System.Windows.Forms.Button();
            this.listBox_Wyświetl = new System.Windows.Forms.ListBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox_2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_Otwórz = new System.Windows.Forms.Button();
            this.textBox_nazwaPliku = new System.Windows.Forms.TextBox();
            this.button_Zapisz = new System.Windows.Forms.Button();
            this.groupBox_1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox_3 = new System.Windows.Forms.GroupBox();
            this.groupBox_4 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox_2.SuspendLayout();
            this.groupBox_1.SuspendLayout();
            this.groupBox_3.SuspendLayout();
            this.groupBox_4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_GenerujSezon
            // 
            this.button_GenerujSezon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_GenerujSezon.Location = new System.Drawing.Point(6, 24);
            this.button_GenerujSezon.Name = "button_GenerujSezon";
            this.button_GenerujSezon.Size = new System.Drawing.Size(175, 40);
            this.button_GenerujSezon.TabIndex = 0;
            this.button_GenerujSezon.Text = "Generuj harmonogram";
            this.button_GenerujSezon.UseVisualStyleBackColor = true;
            this.button_GenerujSezon.Click += new System.EventHandler(this.ButtonGenerujSezon_Click);
            // 
            // listBox_Wyświetl
            // 
            this.listBox_Wyświetl.FormattingEnabled = true;
            this.listBox_Wyświetl.Location = new System.Drawing.Point(6, 14);
            this.listBox_Wyświetl.Name = "listBox_Wyświetl";
            this.listBox_Wyświetl.Size = new System.Drawing.Size(400, 472);
            this.listBox_Wyświetl.TabIndex = 1;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(6, 19);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(79, 17);
            this.radioButton1.TabIndex = 4;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "2017-08-05";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(91, 19);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(79, 17);
            this.radioButton2.TabIndex = 5;
            this.radioButton2.Text = "2017-08-12";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(6, 42);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(79, 17);
            this.radioButton3.TabIndex = 6;
            this.radioButton3.Text = "2017-08-19";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(91, 42);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(79, 17);
            this.radioButton4.TabIndex = 7;
            this.radioButton4.Text = "2017-08-26";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Checked = true;
            this.radioButton5.Location = new System.Drawing.Point(6, 19);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(79, 17);
            this.radioButton5.TabIndex = 8;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "2018-02-03";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(91, 19);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(79, 17);
            this.radioButton6.TabIndex = 9;
            this.radioButton6.Text = "2018-02-10";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(6, 42);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(79, 17);
            this.radioButton7.TabIndex = 10;
            this.radioButton7.Text = "2018-02-17";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(91, 42);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(79, 17);
            this.radioButton8.TabIndex = 11;
            this.radioButton8.Text = "2018-02-24";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Controls.Add(this.radioButton3);
            this.groupBox1.Controls.Add(this.radioButton4);
            this.groupBox1.Location = new System.Drawing.Point(6, 58);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(175, 72);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton5);
            this.groupBox2.Controls.Add(this.radioButton6);
            this.groupBox2.Controls.Add(this.radioButton8);
            this.groupBox2.Controls.Add(this.radioButton7);
            this.groupBox2.Location = new System.Drawing.Point(6, 179);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(175, 72);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            // 
            // groupBox_2
            // 
            this.groupBox_2.Controls.Add(this.label2);
            this.groupBox_2.Controls.Add(this.label1);
            this.groupBox_2.Controls.Add(this.groupBox1);
            this.groupBox_2.Controls.Add(this.groupBox2);
            this.groupBox_2.Enabled = false;
            this.groupBox_2.Location = new System.Drawing.Point(12, 99);
            this.groupBox_2.Name = "groupBox_2";
            this.groupBox_2.Size = new System.Drawing.Size(186, 258);
            this.groupBox_2.TabIndex = 15;
            this.groupBox_2.TabStop = false;
            this.groupBox_2.Text = "Krok 2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(9, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 26);
            this.label2.TabIndex = 16;
            this.label2.Text = "Wybierz datę rozpoczęcia \r\nrundy zimowej";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(9, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 26);
            this.label1.TabIndex = 14;
            this.label1.Text = "Wybierz datę rozpoczęcia \r\nrundy zimowej";
            // 
            // button_Otwórz
            // 
            this.button_Otwórz.Location = new System.Drawing.Point(6, 52);
            this.button_Otwórz.Name = "button_Otwórz";
            this.button_Otwórz.Size = new System.Drawing.Size(75, 23);
            this.button_Otwórz.TabIndex = 16;
            this.button_Otwórz.Text = "Otwórz";
            this.button_Otwórz.UseVisualStyleBackColor = true;
            this.button_Otwórz.Click += new System.EventHandler(this.button_Otwórz_Click);
            // 
            // textBox_nazwaPliku
            // 
            this.textBox_nazwaPliku.Enabled = false;
            this.textBox_nazwaPliku.Location = new System.Drawing.Point(86, 54);
            this.textBox_nazwaPliku.Name = "textBox_nazwaPliku";
            this.textBox_nazwaPliku.Size = new System.Drawing.Size(94, 20);
            this.textBox_nazwaPliku.TabIndex = 17;
            // 
            // button_Zapisz
            // 
            this.button_Zapisz.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.button_Zapisz.Location = new System.Drawing.Point(6, 24);
            this.button_Zapisz.Name = "button_Zapisz";
            this.button_Zapisz.Size = new System.Drawing.Size(175, 40);
            this.button_Zapisz.TabIndex = 18;
            this.button_Zapisz.Text = "Zapisz do pliku";
            this.button_Zapisz.UseVisualStyleBackColor = true;
            this.button_Zapisz.Click += new System.EventHandler(this.button_Zapisz_Click);
            // 
            // groupBox_1
            // 
            this.groupBox_1.Controls.Add(this.label3);
            this.groupBox_1.Controls.Add(this.button_Otwórz);
            this.groupBox_1.Controls.Add(this.textBox_nazwaPliku);
            this.groupBox_1.Location = new System.Drawing.Point(12, 12);
            this.groupBox_1.Name = "groupBox_1";
            this.groupBox_1.Size = new System.Drawing.Size(186, 81);
            this.groupBox_1.TabIndex = 19;
            this.groupBox_1.TabStop = false;
            this.groupBox_1.Text = "Krok 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "Otwórz plik: ZESPOLY.FDB";
            // 
            // groupBox_3
            // 
            this.groupBox_3.Controls.Add(this.button_GenerujSezon);
            this.groupBox_3.Enabled = false;
            this.groupBox_3.Location = new System.Drawing.Point(12, 363);
            this.groupBox_3.Name = "groupBox_3";
            this.groupBox_3.Size = new System.Drawing.Size(186, 70);
            this.groupBox_3.TabIndex = 20;
            this.groupBox_3.TabStop = false;
            this.groupBox_3.Text = "Krok 3";
            // 
            // groupBox_4
            // 
            this.groupBox_4.Controls.Add(this.button_Zapisz);
            this.groupBox_4.Enabled = false;
            this.groupBox_4.Location = new System.Drawing.Point(12, 439);
            this.groupBox_4.Name = "groupBox_4";
            this.groupBox_4.Size = new System.Drawing.Size(186, 70);
            this.groupBox_4.TabIndex = 21;
            this.groupBox_4.TabStop = false;
            this.groupBox_4.Text = "Krok 4";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.listBox_Wyświetl);
            this.groupBox3.Location = new System.Drawing.Point(204, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(412, 497);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Lista";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 520);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox_4);
            this.Controls.Add(this.groupBox_3);
            this.Controls.Add(this.groupBox_1);
            this.Controls.Add(this.groupBox_2);
            this.Name = "Form1";
            this.Text = "Generuj harmonogram rozgrywek 2017/18";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox_2.ResumeLayout(false);
            this.groupBox_2.PerformLayout();
            this.groupBox_1.ResumeLayout(false);
            this.groupBox_1.PerformLayout();
            this.groupBox_3.ResumeLayout(false);
            this.groupBox_4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_GenerujSezon;
        private System.Windows.Forms.ListBox listBox_Wyświetl;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox_2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_Otwórz;
        private System.Windows.Forms.TextBox textBox_nazwaPliku;
        private System.Windows.Forms.Button button_Zapisz;
        private System.Windows.Forms.GroupBox groupBox_1;
        private System.Windows.Forms.GroupBox groupBox_3;
        private System.Windows.Forms.GroupBox groupBox_4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}

