﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HarmonogramRozgrywek
{
    class GenerujDaty
    {
        private DateTime dataRundaZimowa, dataRundaLetnia, data;
        public GenerujDaty() { }
        public DateTime DataRundaZimowa
        {
            set
            {
                this.dataRundaZimowa = value;
            }
        }
        public DateTime DataRundaLetnia
        {
            set
            {
                this.dataRundaLetnia = value;
            }
        }
        public DateTime[] Generuj()
        {
            data = this.dataRundaZimowa.Date;
            DateTime[] tablicaTerminarz = new DateTime[60];
            bool przerwa = true;
            int kontynuacjaPętli = 0;
            while (przerwa)
            {
                for (int x = kontynuacjaPętli; x < tablicaTerminarz.Length;)
                {
                    tablicaTerminarz[x++] = data;
                    data = data.AddDays(1);
                    if (x == 29)
                    {
                        tablicaTerminarz[x] = data;
                        data = this.dataRundaLetnia.Date;
                        kontynuacjaPętli = 30;
                        break;
                    }
                    else if (x == 59)
                    {
                        tablicaTerminarz[x] = data;
                        przerwa = false;
                        break;
                    }
                    tablicaTerminarz[x++] = data;
                    data = data.AddDays(6);
                }
            }
            return tablicaTerminarz;
        }
    }
}
